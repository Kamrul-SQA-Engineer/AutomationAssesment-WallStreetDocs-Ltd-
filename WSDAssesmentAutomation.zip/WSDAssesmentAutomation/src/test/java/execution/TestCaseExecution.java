package execution;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import environment.BaseClass;
import pages.CartPage;
import pages.HomePage;

public class TestCaseExecution extends BaseClass{
	private HomePage homepage;
	private CartPage cartpage;

	@BeforeMethod
	public void setupTest() {
		setup();
		homepage = new HomePage(getDriver());
		cartpage = new CartPage(getDriver());
	}

	@Test(priority=1)
	public void ProductSearch() throws InterruptedException {
		//search the product
		homepage.SearchProduct();
		homepage.VerifySearchResult();
		Thread.sleep(5000);
	}
	
	@Test(priority=2)
	public void AddToCart() throws InterruptedException {
		homepage.AddProduct();
		Thread.sleep(5000);
		cartpage.VerifyProduct();
		
		Thread.sleep(5000);
	}
	
	@Test(priority=3)
	public void RemoveFromCart() throws InterruptedException {
		homepage.AddProduct();
		Thread.sleep(5000);
		cartpage.RemoveProduct();
		
	}
	
	@AfterMethod
	public void closeBrowser() {
		closeDown();

	}

}

