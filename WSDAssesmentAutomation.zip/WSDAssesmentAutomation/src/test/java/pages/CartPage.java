package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

public class CartPage {

	protected WebDriver driver;

	// constructor
	public CartPage(WebDriver driver) {
		this.driver = driver;

	}

	// actions
	public void VerifyProduct() {
		//click the cart button
		driver.findElement(By.xpath("/html/body/div[2]/header/div[2]/div[1]/a/span[2]")).click();
		
		// check product name
		WebElement productname = driver.findElement(
				By.xpath("/html/body/div[2]/header/div[2]/div[1]/div/div/div/div[2]/div[4]/ol/li/div/div/strong/a"));
		String actualText1 = productname.getText();
		System.out.println(actualText1);
		String expectedText1 = "Radiant Tee";

		// Hard Assertion for the match the added product
		Assert.assertEquals(actualText1, expectedText1, "Text does not match!");
		System.out.println("Accurate Item Added to the cart");

		// check product quantity
		WebElement productquantity = driver.findElement(By.xpath(
				"/html/body/div[2]/header/div[2]/div[1]/div/div/div/div[2]/div[4]/ol/li/div/div/div[2]/div[2]/input"));
		String actualText2 = productquantity.getText();
		System.out.println(actualText2);
		String expectedText2 = "";

		// Hard Assertion for the match the added product
		Assert.assertEquals(actualText2, expectedText2, "Text does not match!");
		System.out.println("Accurate No of Item Added to the cart");

		// check product price
		WebElement productprice = driver.findElement(By.xpath(
				"/html/body/div[2]/header/div[2]/div[1]/div/div/div/div[2]/div[4]/ol/li/div/div/div[2]/div[1]/span/span/span/span"));
		String actualText3 = productprice.getText();
		System.out.println(actualText3);
		String expectedText3 = "$22.00";

		// Hard Assertion for the match the added product
		Assert.assertEquals(actualText3, expectedText3, "Text does not match!");
		System.out.println("Accurate Item Added to the cart");
	}
	
	
	public void RemoveProduct() {
		//click the cart button
		driver.findElement(By.xpath("/html/body/div[2]/header/div[2]/div[1]/a/span[2]")).click();
		//click delete button
		driver.findElement(By.xpath("/html/body/div[2]/header/div[2]/div[1]/div/div/div/div[2]/div[4]/ol/li/div/div/div[3]/div[2]/a")).click();
		//click ok
		driver.findElement(By.xpath("/html/body/div[4]/aside[2]/div[2]/footer/button[2]/span")).click();
		
		//click the cart button again
		driver.findElement(By.xpath("/html/body/div[2]/header/div[2]/div[1]/a/span[2]")).click();
		
		// check the status after delete product
		WebElement popup = driver.findElement(By.xpath(
				"/html/body/div[2]/header/div[2]/div[1]/div/div/div/div[2]/strong"));
		String actualText4 = popup.getText();
		System.out.println(actualText4);
		String expectedText4 = "You have no items in your shopping cart.";

		// Hard Assertion for the match the added product
		Assert.assertEquals(actualText4, expectedText4, "Text does not match!");
		System.out.println("There is no product");
	
	}
}
