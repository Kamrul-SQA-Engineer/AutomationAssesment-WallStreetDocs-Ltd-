package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

public class HomePage {
	protected WebDriver driver;

	// constructor
	public HomePage(WebDriver driver) {
		this.driver = driver;

	}

	// actions
	public void SearchProduct() {
		WebElement searchBox = driver.findElement(By.id("search"));
		searchBox.sendKeys("Fusion");
		searchBox.sendKeys(Keys.ENTER);
		System.out.println("Enter Fusion to the search bar and click enter");
	}

	public void VerifySearchResult() {
        WebElement element = driver.findElement(By.xpath("/html/body/div[2]/main/div[3]/div[1]/div[2]/div[2]/ol/li/div/div/strong/a"));
        String actualText = element.getText();
        System.out.println(actualText);
        String expectedText = "Fusion Backpack";

        // Hard Assertion for the match the search product
        Assert.assertEquals(actualText, expectedText, "Text does not match!");
        System.out.println("Search item checked successfully");

	}

	public void AddProduct() {
		//click the Radiant Tee product
		driver.findElement(By.xpath("/html/body/div[2]/main/div[3]/div/div[2]/div[5]/div/div/ol/li[1]/div/a/span/span/img")).click();
		//select the size
		driver.findElement(By.xpath("/html/body/div[2]/main/div[2]/div/div[1]/div[4]/form/div[1]/div/div/div[1]/div/div[2]")).click();
		//select the color
		driver.findElement(By.xpath("/html/body/div[2]/main/div[2]/div/div[1]/div[4]/form/div[1]/div/div/div[2]/div/div[1]")).click();
		//click add to cart
		driver.findElement(By.id("product-addtocart-button")).click();
		
	}

}